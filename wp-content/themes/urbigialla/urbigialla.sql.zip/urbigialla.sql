-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Dic 22, 2023 alle 16:50
-- Versione del server: 8.0.35-0ubuntu0.22.04.1
-- Versione PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urbigialla`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_commentmeta`
--

CREATE TABLE `ug_commentmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `comment_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_comments`
--

CREATE TABLE `ug_comments` (
  `comment_ID` bigint UNSIGNED NOT NULL,
  `comment_post_ID` bigint UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_links`
--

CREATE TABLE `ug_links` (
  `link_id` bigint UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_options`
--

CREATE TABLE `ug_options` (
  `option_id` bigint UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dump dei dati per la tabella `ug_options`
--

INSERT INTO `ug_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://urbigialla.com', 'yes'),
(2, 'home', 'http://urbigialla.com', 'yes'),
(3, 'blogname', 'Urbigialla', 'yes'),
(4, 'blogdescription', 'Un nuovo sito targato WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'emanuele.ferrarini@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'G:i', 'yes'),
(25, 'links_updated_date_format', 'j F Y G:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'rewrite_rules', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:31:\"query-monitor/query-monitor.php\";i:1;s:60:\"CMB2-field-Leaflet-Geocoder-master/cmb-field-leaflet-map.php\";i:2;s:13:\"cmb2/init.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'urbigialla', 'yes'),
(41, 'stylesheet', 'urbigialla', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '56657', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', 'Europe/Rome', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1715853634', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'ug_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'it_IT', 'yes'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:158:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Articoli recenti</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:228:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Commenti recenti</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:145:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archivi</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:149:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categorie</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}s:13:\"array_version\";i:3;}', 'yes'),
(105, 'cron', 'a:7:{i:1700471647;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1700504019;a:5:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1700504039;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1700504040;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1700511578;a:1:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1701072974;a:1:{s:30:\"wp_delete_temp_updater_backups\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(121, 'recovery_keys', 'a:0:{}', 'yes'),
(122, 'theme_mods_twentytwentytwo', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1646591351;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(124, 'https_detection_errors', 'a:1:{s:20:\"https_request_failed\";a:1:{i:0;s:24:\"Richiesta HTTPS fallita.\";}}', 'yes'),
(165, 'finished_updating_comment_type', '1', 'yes'),
(173, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(175, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(178, 'theme_mods_urbigialla', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:2:{s:6:\"menu-1\";i:3;s:6:\"menu-2\";i:6;}}', 'yes'),
(179, 'current_theme', 'Urbigialla', 'yes'),
(180, 'theme_switched', '', 'yes'),
(181, 'theme_switched_via_customizer', '', 'yes'),
(182, 'customize_stashed_theme_mods', 'a:0:{}', 'no'),
(185, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(195, 'wp_calendar_block_has_published_posts', '', 'yes'),
(204, 'recently_activated', 'a:0:{}', 'yes'),
(205, 'recovery_mode_email_last_sent', '1683364940', 'yes'),
(206, 'category_children', 'a:0:{}', 'yes'),
(233, 'category_8', 'a:3:{s:3:\"img\";s:73:\"http://urbigialla.com/wp-content/uploads/2022/03/pizza-2000614_1920-1.jpg\";s:5:\"color\";s:7:\"#dd0d44\";s:8:\"head_img\";s:86:\"http://urbigialla.com/wp-content/uploads/2022/03/pizza-2000614_1920-e1647095337915.jpg\";}', 'yes'),
(249, '_transient_health-check-site-status-result', '{\"good\":17,\"recommended\":3,\"critical\":1}', 'yes'),
(279, 'att_luoghi_children', 'a:0:{}', 'yes'),
(433, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:28:\"emanuele.ferrarini@gmail.com\";s:7:\"version\";s:5:\"6.4.1\";s:9:\"timestamp\";i:1700301476;}', 'no'),
(467, 'category_10', 'a:3:{s:3:\"img\";s:61:\"http://urbigialla.com/wp-content/uploads/2022/03/salute-1.jpg\";s:8:\"head_img\";s:74:\"http://urbigialla.com/wp-content/uploads/2022/03/salute-e1647094939986.jpg\";s:5:\"color\";s:7:\"#1e73be\";}', 'yes'),
(473, 'category_11', 'a:3:{s:3:\"img\";s:60:\"http://urbigialla.com/wp-content/uploads/2022/03/hobbies.jpg\";s:8:\"head_img\";s:75:\"http://urbigialla.com/wp-content/uploads/2022/03/hobbies-e1647095527436.jpg\";s:5:\"color\";s:7:\"#dd9933\";}', 'yes'),
(482, 'category_12', 'a:3:{s:3:\"img\";s:72:\"http://urbigialla.com/wp-content/uploads/2022/03/pronto-intervento-1.jpg\";s:5:\"color\";s:7:\"#81d742\";s:8:\"head_img\";s:85:\"http://urbigialla.com/wp-content/uploads/2022/03/pronto-intervento-e1647095750847.jpg\";}', 'yes'),
(486, 'category_16', 'a:3:{s:3:\"img\";s:67:\"http://urbigialla.com/wp-content/uploads/2022/03/professionisti.jpg\";s:8:\"head_img\";s:84:\"http://urbigialla.com/wp-content/uploads/2022/03/professionisti-1-e1647095944132.jpg\";s:5:\"color\";s:7:\"#1ebfaf\";}', 'yes'),
(489, 'category_13', 'a:3:{s:3:\"img\";s:58:\"http://urbigialla.com/wp-content/uploads/2022/03/spesa.jpg\";s:8:\"head_img\";s:75:\"http://urbigialla.com/wp-content/uploads/2022/03/spesa-1-e1647096044219.jpg\";s:5:\"color\";s:7:\"#db2382\";}', 'yes'),
(493, 'category_14', 'a:3:{s:3:\"img\";s:58:\"http://urbigialla.com/wp-content/uploads/2022/03/sport.jpg\";s:8:\"head_img\";s:75:\"http://urbigialla.com/wp-content/uploads/2022/03/sport-1-e1647096152654.jpg\";s:5:\"color\";s:7:\"#42d687\";}', 'yes'),
(496, 'category_15', 'a:3:{s:3:\"img\";s:59:\"http://urbigialla.com/wp-content/uploads/2022/03/studio.jpg\";s:5:\"color\";s:7:\"#f79138\";s:8:\"head_img\";s:76:\"http://urbigialla.com/wp-content/uploads/2022/03/studio-1-e1647096299687.jpg\";}', 'yes'),
(504, 'PMXI_Plugin_Options', 'a:28:{s:12:\"info_api_url\";s:27:\"https://www.wpallimport.com\";s:18:\"history_file_count\";i:10000;s:16:\"history_file_age\";i:365;s:15:\"highlight_limit\";i:10000;s:19:\"upload_max_filesize\";i:2048;s:13:\"post_max_size\";i:2048;s:14:\"max_input_time\";i:-1;s:18:\"max_execution_time\";i:-1;s:7:\"dismiss\";i:0;s:16:\"dismiss_speed_up\";i:0;s:18:\"dismiss_manage_top\";i:0;s:21:\"dismiss_manage_bottom\";i:0;s:13:\"html_entities\";i:0;s:11:\"utf8_decode\";i:0;s:12:\"cron_job_key\";s:7:\"Zo4eRf_\";s:10:\"chunk_size\";i:32;s:9:\"pingbacks\";i:1;s:33:\"legacy_special_character_handling\";i:1;s:14:\"case_sensitive\";i:1;s:12:\"session_mode\";s:7:\"default\";s:17:\"enable_ftp_import\";i:0;s:16:\"large_feed_limit\";i:1000;s:26:\"cron_processing_time_limit\";i:59;s:6:\"secure\";i:1;s:11:\"log_storage\";i:5;s:10:\"cron_sleep\";s:0:\"\";s:4:\"port\";s:0:\"\";s:19:\"force_stream_reader\";i:0;}', 'no'),
(505, 'pmxi_is_migrated', '3.6.6', 'yes'),
(553, 'att_categorie_children', 'a:4:{i:8;a:13:{i:0;i:17;i:1;i:18;i:2;i:19;i:3;i:20;i:4;i:21;i:5;i:22;i:6;i:23;i:7;i:24;i:8;i:30;i:9;i:31;i:10;i:36;i:11;i:38;i:12;i:42;}i:13;a:13:{i:0;i:25;i:1;i:26;i:2;i:27;i:3;i:28;i:4;i:29;i:5;i:32;i:6;i:33;i:7;i:34;i:8;i:35;i:9;i:37;i:10;i:39;i:11;i:40;i:12;i:41;}i:10;a:5:{i:0;i:43;i:1;i:44;i:2;i:45;i:3;i:46;i:4;i:47;}i:15;a:5:{i:0;i:48;i:1;i:49;i:2;i:50;i:3;i:51;i:4;i:52;}}', 'yes'),
(630, 'user_count', '1', 'no'),
(631, 'db_upgraded', '', 'yes');
INSERT INTO `ug_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(658, '_transient_dirsize_cache', 'a:509:{s:48:\"/home/emafer/sviluppo/urbigialla/vendor/composer\";i:38280;s:72:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/.github/workflows\";i:5660;s:77:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/.github/ISSUE_TEMPLATE\";i:3436;s:62:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/.github\";i:22583;s:84:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/content\";i:52543;s:93:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/sign-in\";i:1624;s:94:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/blog-rtl\";i:19953;s:93:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/footers\";i:11808;s:95:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/jumbotron\";i:2949;s:94:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/features\";i:185857;s:102:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/offcanvas-navbar\";i:7407;s:92:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/heroes\";i:656484;s:96:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/cheatsheet\";i:89297;s:94:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/checkout\";i:10067;s:93:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/headers\";i:16474;s:91:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/cover\";i:2024;s:94:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/carousel\";i:10799;s:93:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/masonry\";i:4519;s:93:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/pricing\";i:9484;s:93:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/navbars\";i:19125;s:99:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/dashboard-rtl\";i:9475;s:90:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/blog\";i:16710;s:99:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/navbar-bottom\";i:1733;s:98:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/carousel-rtl\";i:10409;s:102:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/starter-template\";i:3777;s:95:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/dashboard\";i:12044;s:97:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/list-groups\";i:10831;s:91:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/album\";i:10756;s:94:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/sidebars\";i:27936;s:93:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/product\";i:8384;s:98:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/navbar-fixed\";i:1681;s:100:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/cheatsheet-rtl\";i:97936;s:95:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/dropdowns\";i:20132;s:90:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/grid\";i:9690;s:92:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/modals\";i:12020;s:95:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/album-rtl\";i:11599;s:106:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/sticky-footer-navbar\";i:2215;s:99:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/sticky-footer\";i:921;s:98:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/checkout-rtl\";i:10376;s:99:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/navbar-static\";i:1665;s:85:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples\";i:1330525;s:86:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/customize\";i:36824;s:82:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/forms\";i:77418;s:87:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/components\";i:409798;s:82:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/about\";i:8199;s:83:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/layout\";i:59858;s:84:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/helpers\";i:15753;s:92:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/getting-started\";i:62402;s:86:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/utilities\";i:88260;s:83:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/extend\";i:9466;s:76:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1\";i:2176044;s:72:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content/docs\";i:2177259;s:67:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/content\";i:2177483;s:95:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/img/examples\";i:1047860;s:95:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/img/favicons\";i:58057;s:86:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/img\";i:1958609;s:85:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/js\";i:616;s:88:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/brand\";i:253225;s:82:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets\";i:2212450;s:75:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1\";i:2212450;s:71:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static/docs\";i:2212450;s:66:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/static\";i:2213252;s:81:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/layouts/partials/home\";i:7291;s:82:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/layouts/partials/icons\";i:21879;s:76:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/layouts/partials\";i:49921;s:76:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/layouts/_default\";i:7253;s:78:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/layouts/shortcodes\";i:7123;s:67:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/layouts\";i:65580;s:76:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/assets/js/vendor\";i:16685;s:69:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/assets/js\";i:23700;s:71:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/assets/scss\";i:36154;s:66:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/assets\";i:59854;s:64:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site/data\";i:12422;s:59:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/site\";i:4529911;s:60:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/build\";i:16585;s:75:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/tests/integration\";i:5633;s:71:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/tests/helpers\";i:1158;s:72:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/tests/unit/dom\";i:26458;s:73:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/tests/unit/util\";i:60385;s:68:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/tests/unit\";i:457901;s:70:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/tests/visual\";i:103825;s:63:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/tests\";i:577235;s:66:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/dist/dom\";i:70793;s:62:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/dist\";i:717317;s:65:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/src/dom\";i:14670;s:66:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/src/util\";i:21773;s:61:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js/src\";i:143890;s:57:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/js\";i:1440130;s:63:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/dist/css\";i:5020243;s:62:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/dist/js\";i:2490828;s:59:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/dist\";i:7511071;s:60:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/nuget\";i:5935;s:66:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/scss/mixins\";i:33415;s:66:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/scss/vendor\";i:10029;s:65:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/scss/forms\";i:22733;s:67:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/scss/helpers\";i:2105;s:69:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/scss/utilities\";i:1737;s:59:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap/scss\";i:254235;s:54:\"/home/emafer/sviluppo/urbigialla/vendor/twbs/bootstrap\";i:14227190;s:44:\"/home/emafer/sviluppo/urbigialla/vendor/twbs\";i:14227190;s:39:\"/home/emafer/sviluppo/urbigialla/vendor\";i:14265648;s:51:\"/home/emafer/sviluppo/urbigialla/wp-content/upgrade\";i:0;s:60:\"/home/emafer/sviluppo/urbigialla/wp-content/languages/themes\";i:132169;s:61:\"/home/emafer/sviluppo/urbigialla/wp-content/languages/plugins\";i:127956;s:53:\"/home/emafer/sviluppo/urbigialla/wp-content/languages\";i:2979260;s:43:\"/home/emafer/sviluppo/urbigialla/wp-content\";i:2983205;s:54:\"/home/emafer/sviluppo/urbigialla/wp-includes/PHPMailer\";i:226303;s:48:\"/home/emafer/sviluppo/urbigialla/wp-includes/ID3\";i:1143654;s:66:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/edit-widgets\";i:108787;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/customize-widgets\";i:27716;s:66:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/block-editor\";i:530671;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/components\";i:462356;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/reusable-blocks\";i:5178;s:74:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/list-reusable-blocks\";i:21928;s:67:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/block-library\";i:696498;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/widgets\";i:27172;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/block-directory\";i:17844;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/edit-site\";i:211045;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/editor\";i:91556;s:68:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/format-library\";i:10926;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/nux\";i:14748;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist/edit-post\";i:210007;s:53:\"/home/emafer/sviluppo/urbigialla/wp-includes/css/dist\";i:2436432;s:48:\"/home/emafer/sviluppo/urbigialla/wp-includes/css\";i:3082955;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/Cache\";i:39607;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/HTTP\";i:11487;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/Net\";i:7493;s:67:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/Content/Type\";i:8015;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/Content\";i:8015;s:70:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/XML/Declaration\";i:7098;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/XML\";i:7098;s:66:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/Decode/HTML\";i:17241;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/Decode\";i:17241;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie/Parse\";i:20551;s:54:\"/home/emafer/sviluppo/urbigialla/wp-includes/SimplePie\";i:458625;s:54:\"/home/emafer/sviluppo/urbigialla/wp-includes/customize\";i:173478;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/random_compat\";i:43330;s:48:\"/home/emafer/sviluppo/urbigialla/wp-includes/IXR\";i:33914;s:49:\"/home/emafer/sviluppo/urbigialla/wp-includes/pomo\";i:53510;s:52:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/crop\";i:20004;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/codemirror\";i:1287141;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/imgareaselect\";i:49024;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/jquery/ui\";i:807133;s:54:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/jquery\";i:1321204;s:53:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/jcrop\";i:24976;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/dist/development\";i:178306;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/dist/vendor\";i:2361962;s:52:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/dist\";i:14935459;s:56:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/thickbox\";i:31185;s:56:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/plupload\";i:490126;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/swfupload\";i:8715;s:70:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/mediaelement/renderers\";i:18880;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/mediaelement\";i:719403;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/themes/inlite\";i:452642;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/themes/modern\";i:446221;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/themes\";i:898863;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/langs\";i:15529;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/utils\";i:18822;s:75:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/skins/lightgray/img\";i:2856;s:77:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/skins/lightgray/fonts\";i:155760;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/skins/lightgray\";i:210254;s:78:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/skins/wordpress/images\";i:14207;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/skins/wordpress\";i:22831;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/skins\";i:233085;s:75:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wpeditimage\";i:37713;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/charmap\";i:31811;s:73:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wpdialogs\";i:3761;s:78:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/directionality\";i:2749;s:68:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/link\";i:32949;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/paste\";i:113193;s:66:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/hr\";i:1347;s:77:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wptextpattern\";i:11923;s:73:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/textcolor\";i:16237;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wpemoji\";i:5099;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/media\";i:57914;s:74:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/fullscreen\";i:7779;s:75:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/colorpicker\";i:4910;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/lists\";i:97383;s:76:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wpautoresize\";i:8332;s:73:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wpgallery\";i:4806;s:76:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/compat3x/css\";i:8179;s:72:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/compat3x\";i:21758;s:73:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wordpress\";i:50609;s:70:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wplink\";i:26476;s:70:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/wpview\";i:8994;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/image\";i:55874;s:72:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins/tabfocus\";i:5336;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce/plugins\";i:606953;s:55:\"/home/emafer/sviluppo/urbigialla/wp-includes/js/tinymce\";i:2853635;s:47:\"/home/emafer/sviluppo/urbigialla/wp-includes/js\";i:24147665;s:50:\"/home/emafer/sviluppo/urbigialla/wp-includes/fonts\";i:289826;s:52:\"/home/emafer/sviluppo/urbigialla/wp-includes/widgets\";i:157313;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/Text/Diff/Engine\";i:31662;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/Text/Diff/Renderer\";i:5535;s:54:\"/home/emafer/sviluppo/urbigialla/wp-includes/Text/Diff\";i:44010;s:49:\"/home/emafer/sviluppo/urbigialla/wp-includes/Text\";i:56929;s:79:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comments-pagination-numbers\";i:4253;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/social-links\";i:56664;s:67:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/latest-comments\";i:7625;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/buttons\";i:15823;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/shortcode\";i:8171;s:68:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/query-pagination\";i:13862;s:65:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-comments\";i:17063;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/avatar\";i:7577;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/audio\";i:12016;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/columns\";i:14308;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/heading\";i:4933;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/latest-posts\";i:16573;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-date\";i:950;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/freeform\";i:42245;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/page-list\";i:12661;s:70:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comment-reply-link\";i:837;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/categories\";i:7362;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/block\";i:4929;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/site-title\";i:4627;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/site-tagline\";i:4317;s:68:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comment-template\";i:4411;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/site-logo\";i:20569;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/cover\";i:82890;s:65:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/template-part\";i:8133;s:67:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comment-content\";i:4213;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/quote\";i:11894;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comment-edit-link\";i:995;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/paragraph\";i:10449;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/table\";i:30710;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/calendar\";i:5144;s:67:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/navigation-link\";i:17439;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/navigation\";i:133558;s:68:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/query-no-results\";i:483;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-content\";i:439;s:65:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/legacy-widget\";i:501;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/read-more\";i:5292;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/query-title\";i:1027;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/query\";i:8879;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/gallery\";i:84238;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-featured-image\";i:23813;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/text-columns\";i:8990;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/loginout\";i:510;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/search\";i:17006;s:56:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/more\";i:6746;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-author\";i:5670;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/home-link\";i:714;s:73:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-author-biography\";i:881;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/missing\";i:564;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/button\";i:21550;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/verse\";i:4425;s:65:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-template\";i:12873;s:76:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comments-pagination-next\";i:870;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/pullquote\";i:18862;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/tag-cloud\";i:5886;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/pattern\";i:324;s:70:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-comments-form\";i:15260;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-terms\";i:4087;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/column\";i:880;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comment-author-name\";i:1032;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/embed\";i:19754;s:77:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/query-pagination-previous\";i:873;s:73:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/query-pagination-next\";i:861;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comments-pagination\";i:14298;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comment-date\";i:959;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/media-text\";i:19937;s:76:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/query-pagination-numbers\";i:4670;s:80:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comments-pagination-previous\";i:882;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/preformatted\";i:4338;s:56:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/list\";i:4797;s:56:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/code\";i:7942;s:66:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comments-title\";i:4520;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/spacer\";i:10019;s:70:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/navigation-submenu\";i:8840;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/group\";i:15315;s:56:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/file\";i:15738;s:72:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-navigation-link\";i:920;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/image\";i:29712;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/separator\";i:14141;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-excerpt\";i:7543;s:64:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/widget-group\";i:319;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/social-link\";i:5172;s:56:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/html\";i:6703;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/archives\";i:6812;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/video\";i:22069;s:68:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/term-description\";i:728;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/nextpage\";i:6021;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/post-title\";i:4622;s:55:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/rss\";i:11940;s:71:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks/comments-query-loop\";i:3955;s:51:\"/home/emafer/sviluppo/urbigialla/wp-includes/blocks\";i:1368502;s:51:\"/home/emafer/sviluppo/urbigialla/wp-includes/assets\";i:11605;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/certificates\";i:233231;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/images/crystal\";i:15541;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/images/media\";i:2419;s:55:\"/home/emafer/sviluppo/urbigialla/wp-includes/images/wlw\";i:4413;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/images/smilies\";i:10082;s:51:\"/home/emafer/sviluppo/urbigialla/wp-includes/images\";i:103747;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/block-supports\";i:65329;s:55:\"/home/emafer/sviluppo/urbigialla/wp-includes/php-compat\";i:1203;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/rest-api/endpoints\";i:719276;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/rest-api/fields\";i:22314;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/rest-api/search\";i:15180;s:53:\"/home/emafer/sviluppo/urbigialla/wp-includes/rest-api\";i:842532;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/block-patterns\";i:8843;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/sitemaps/providers\";i:16471;s:53:\"/home/emafer/sviluppo/urbigialla/wp-includes/sitemaps\";i:46403;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Auth\";i:1939;s:59:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Proxy\";i:3488;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Transport\";i:30090;s:68:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Exception/HTTP\";i:14365;s:73:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Exception/Transport\";i:919;s:63:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Exception\";i:16778;s:61:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Utility\";i:3310;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Response\";i:2135;s:60:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests/Cookie\";i:3865;s:53:\"/home/emafer/sviluppo/urbigialla/wp-includes/Requests\";i:139225;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/lib\";i:84845;s:68:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/PHP52\";i:4116;s:83:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core32/Curve25519/Ge\";i:8177;s:80:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core32/Curve25519\";i:122690;s:82:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core32/SecretStream\";i:3656;s:78:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core32/ChaCha20\";i:6407;s:78:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core32/Poly1305\";i:15965;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core32\";i:436924;s:81:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core/Curve25519/Ge\";i:7881;s:78:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core/Curve25519\";i:121645;s:80:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core/SecretStream\";i:3624;s:76:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core/ChaCha20\";i:5264;s:76:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core/Poly1305\";i:12912;s:74:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core/Base64\";i:22135;s:67:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src/Core\";i:452672;s:62:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/src\";i:1204643;s:88:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/namespaced/Core/Curve25519/Ge\";i:602;s:85:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/namespaced/Core/Curve25519\";i:820;s:83:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/namespaced/Core/ChaCha20\";i:224;s:83:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/namespaced/Core/Poly1305\";i:112;s:74:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/namespaced/Core\";i:2444;s:69:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat/namespaced\";i:2698;s:58:\"/home/emafer/sviluppo/urbigialla/wp-includes/sodium_compat\";i:1298275;s:57:\"/home/emafer/sviluppo/urbigialla/wp-includes/theme-compat\";i:15442;s:44:\"/home/emafer/sviluppo/urbigialla/wp-includes\";i:40595423;s:60:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors/sunrise\";i:78983;s:59:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors/coffee\";i:76468;s:58:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors/ocean\";i:75697;s:62:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors/ectoplasm\";i:78210;s:57:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors/blue\";i:78246;s:58:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors/light\";i:78840;s:61:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors/midnight\";i:79043;s:59:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors/modern\";i:78738;s:52:\"/home/emafer/sviluppo/urbigialla/wp-admin/css/colors\";i:647862;s:45:\"/home/emafer/sviluppo/urbigialla/wp-admin/css\";i:2512039;s:52:\"/home/emafer/sviluppo/urbigialla/wp-admin/js/widgets\";i:139404;s:44:\"/home/emafer/sviluppo/urbigialla/wp-admin/js\";i:1906208;s:49:\"/home/emafer/sviluppo/urbigialla/wp-admin/network\";i:124247;s:48:\"/home/emafer/sviluppo/urbigialla/wp-admin/images\";i:390372;s:46:\"/home/emafer/sviluppo/urbigialla/wp-admin/user\";i:3418;s:47:\"/home/emafer/sviluppo/urbigialla/wp-admin/maint\";i:7260;s:50:\"/home/emafer/sviluppo/urbigialla/wp-admin/includes\";i:2903403;s:41:\"/home/emafer/sviluppo/urbigialla/wp-admin\";i:8730816;s:32:\"/home/emafer/sviluppo/urbigialla\";i:66778493;s:67:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/.idea\";i:6059;s:112:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/wp-bootstrap/wp-bootstrap-navwalker/.github\";i:1966;s:110:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/wp-bootstrap/wp-bootstrap-navwalker/tests\";i:24686;s:108:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/wp-bootstrap/wp-bootstrap-navwalker/bin\";i:3920;s:104:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/wp-bootstrap/wp-bootstrap-navwalker\";i:126135;s:81:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/wp-bootstrap\";i:126135;s:106:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/composer/installers/.github/workflows\";i:4035;s:96:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/composer/installers/.github\";i:4035;s:112:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/composer/installers/src/Composer/Installers\";i:77612;s:101:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/composer/installers/src/Composer\";i:77612;s:92:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/composer/installers/src\";i:78080;s:88:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/composer/installers\";i:86195;s:77:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/composer\";i:137165;s:96:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/components/font-awesome/css\";i:532296;s:97:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/components/font-awesome/less\";i:213032;s:101:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/components/font-awesome/webfonts\";i:814780;s:97:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/components/font-awesome/scss\";i:220228;s:92:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/components/font-awesome\";i:1784996;s:79:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/components\";i:1784996;s:101:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/.github/workflows\";i:5660;s:106:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/.github/ISSUE_TEMPLATE\";i:3436;s:91:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/.github\";i:22583;s:113:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/content\";i:52543;s:122:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/sign-in\";i:1624;s:123:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/blog-rtl\";i:19953;s:122:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/footers\";i:11808;s:124:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/jumbotron\";i:2949;s:123:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/features\";i:185857;s:131:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/offcanvas-navbar\";i:7407;s:121:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/heroes\";i:656484;s:125:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/cheatsheet\";i:89297;s:123:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/checkout\";i:10067;s:122:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/headers\";i:16474;s:120:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/cover\";i:2024;s:123:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/carousel\";i:10799;s:122:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/masonry\";i:4519;s:122:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/pricing\";i:9484;s:122:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/navbars\";i:19125;s:128:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/dashboard-rtl\";i:9475;s:119:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/blog\";i:16710;s:128:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/navbar-bottom\";i:1733;s:127:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/carousel-rtl\";i:10409;s:131:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/starter-template\";i:3777;s:124:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/dashboard\";i:12044;s:126:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/list-groups\";i:10831;s:120:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/album\";i:10756;s:123:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/sidebars\";i:27936;s:122:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/product\";i:8384;s:127:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/navbar-fixed\";i:1681;s:129:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/cheatsheet-rtl\";i:97936;s:124:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/dropdowns\";i:20132;s:119:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/grid\";i:9690;s:121:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/modals\";i:12020;s:124:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/album-rtl\";i:11599;s:135:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/sticky-footer-navbar\";i:2215;s:128:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/sticky-footer\";i:921;s:127:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/checkout-rtl\";i:10376;s:128:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples/navbar-static\";i:1665;s:114:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/examples\";i:1330525;s:115:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/customize\";i:36824;s:111:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/forms\";i:77418;s:116:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/components\";i:409798;s:111:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/about\";i:8199;s:112:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/layout\";i:59858;s:113:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/helpers\";i:15753;s:121:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/getting-started\";i:62402;s:115:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/utilities\";i:88260;s:112:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1/extend\";i:9466;s:105:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs/5.1\";i:2176044;s:101:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content/docs\";i:2177259;s:96:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/content\";i:2177483;s:124:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/img/examples\";i:1047860;s:124:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/img/favicons\";i:58057;s:115:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/img\";i:1958609;s:114:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/js\";i:616;s:117:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets/brand\";i:253225;s:111:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1/assets\";i:2212450;s:104:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static/docs/5.1\";i:2212450;s:100:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static/docs\";i:2212450;s:95:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/static\";i:2213252;s:110:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/layouts/partials/home\";i:7291;s:111:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/layouts/partials/icons\";i:21879;s:105:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/layouts/partials\";i:49921;s:105:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/layouts/_default\";i:7253;s:107:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/layouts/shortcodes\";i:7123;s:96:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/layouts\";i:65580;s:105:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/assets/js/vendor\";i:16685;s:98:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/assets/js\";i:23700;s:100:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/assets/scss\";i:36154;s:95:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/assets\";i:59854;s:93:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site/data\";i:12422;s:88:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/site\";i:4529911;s:89:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/build\";i:16585;s:104:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/tests/integration\";i:5633;s:100:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/tests/helpers\";i:1158;s:101:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/tests/unit/dom\";i:26458;s:102:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/tests/unit/util\";i:60385;s:97:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/tests/unit\";i:457901;s:99:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/tests/visual\";i:103825;s:92:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/tests\";i:577235;s:95:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/dist/dom\";i:70793;s:91:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/dist\";i:717317;s:94:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/src/dom\";i:14670;s:95:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/src/util\";i:21773;s:90:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js/src\";i:143890;s:86:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/js\";i:1440130;s:92:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/dist/css\";i:5020243;s:91:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/dist/js\";i:2490828;s:88:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/dist\";i:7511071;s:89:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/nuget\";i:5935;s:95:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/scss/mixins\";i:33415;s:95:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/scss/vendor\";i:10029;s:94:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/scss/forms\";i:22733;s:96:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/scss/helpers\";i:2105;s:98:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/scss/utilities\";i:1737;s:88:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap/scss\";i:254235;s:83:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs/bootstrap\";i:14227190;s:73:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/twbs\";i:14227190;s:88:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/drmonty/leaflet/css\";i:14281;s:87:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/drmonty/leaflet/js\";i:1592835;s:91:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/drmonty/leaflet/images\";i:6503;s:84:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/drmonty/leaflet\";i:1616751;s:76:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor/drmonty\";i:1616751;s:68:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/vendor\";i:17892415;s:79:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/include/post-type\";i:13452;s:69:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/include\";i:13452;s:71:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/assets/js\";i:1406;s:75:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/assets/images\";i:38140;s:68:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla/assets\";i:39546;s:61:\"/home/emafer/sviluppo/urbigialla/wp-content/themes/urbigialla\";i:19364712;s:50:\"/home/emafer/sviluppo/urbigialla/wp-content/themes\";i:19364740;s:80:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/output/headers\";i:4711;s:76:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/output/raw\";i:9884;s:77:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/output/html\";i:149573;s:72:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/output\";i:181272;s:77:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/dispatchers\";i:36116;s:76:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/collectors\";i:133284;s:72:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/assets\";i:69329;s:73:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/classes\";i:76487;s:76:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor/wp-content\";i:3917;s:65:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins/query-monitor\";i:546086;s:51:\"/home/emafer/sviluppo/urbigialla/wp-content/plugins\";i:546114;s:69:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/wpallimport/files\";i:27383;s:68:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/wpallimport/temp\";i:0;s:71:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/wpallimport/history\";i:0;s:68:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/wpallimport/logs\";i:0;s:104:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/wpallimport/uploads/cec49354577cba9f1ef9d157c12b541c\";i:27383;s:71:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/wpallimport/uploads\";i:27383;s:63:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/wpallimport\";i:54766;s:59:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/2022/03\";i:19280451;s:59:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/2022/07\";i:0;s:56:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads/2022\";i:19280451;s:51:\"/home/emafer/sviluppo/urbigialla/wp-content/uploads\";i:19335217;}', 'yes'),
(937, 'wp_attachment_pages_enabled', '1', 'yes'),
(941, '_site_transient_timeout_php_check_990bfacb848fa087bcfc06850f5e4447', '1700906278', 'no'),
(942, '_site_transient_php_check_990bfacb848fa087bcfc06850f5e4447', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:3:\"7.0\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(945, '_site_transient_timeout_browser_debbccfe2f72c3b86310fbb40fe0c741', '1700906435', 'no'),
(946, '_site_transient_browser_debbccfe2f72c3b86310fbb40fe0c741', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:9:\"111.0.0.0\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(947, 'can_compress_scripts', '0', 'yes'),
(970, '_site_transient_timeout_theme_roots', '1700469972', 'no'),
(971, '_site_transient_theme_roots', 'a:4:{s:7:\"temaGov\";s:7:\"/themes\";s:16:\"twentytwentyfour\";s:7:\"/themes\";s:17:\"twentytwentythree\";s:7:\"/themes\";s:10:\"urbigialla\";s:7:\"/themes\";}', 'no');
INSERT INTO `ug_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(974, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/it_IT/wordpress-6.4.1.zip\";s:6:\"locale\";s:5:\"it_IT\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/it_IT/wordpress-6.4.1.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.4.1\";s:7:\"version\";s:5:\"6.4.1\";s:11:\"php_version\";s:5:\"7.0.0\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"6.4\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1700468176;s:15:\"version_checked\";s:5:\"6.4.1\";s:12:\"translations\";a:0:{}}', 'no'),
(975, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1700468176;s:7:\"checked\";a:4:{s:7:\"temaGov\";s:5:\"0.0.1\";s:16:\"twentytwentyfour\";s:3:\"1.0\";s:17:\"twentytwentythree\";s:3:\"1.1\";s:10:\"urbigialla\";s:3:\"1.1\";}s:8:\"response\";a:1:{s:17:\"twentytwentythree\";a:6:{s:5:\"theme\";s:17:\"twentytwentythree\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:47:\"https://wordpress.org/themes/twentytwentythree/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/theme/twentytwentythree.1.3.zip\";s:8:\"requires\";s:3:\"6.1\";s:12:\"requires_php\";s:3:\"5.6\";}}s:9:\"no_update\";a:1:{s:16:\"twentytwentyfour\";a:6:{s:5:\"theme\";s:16:\"twentytwentyfour\";s:11:\"new_version\";s:3:\"1.0\";s:3:\"url\";s:46:\"https://wordpress.org/themes/twentytwentyfour/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/theme/twentytwentyfour.1.0.zip\";s:8:\"requires\";s:3:\"6.4\";s:12:\"requires_php\";s:3:\"7.0\";}}s:12:\"translations\";a:0:{}}', 'no'),
(976, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1700468177;s:8:\"response\";a:1:{s:31:\"query-monitor/query-monitor.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/query-monitor\";s:4:\"slug\";s:13:\"query-monitor\";s:6:\"plugin\";s:31:\"query-monitor/query-monitor.php\";s:11:\"new_version\";s:6:\"3.15.0\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/query-monitor/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/query-monitor.3.15.0.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2994095\";s:3:\"svg\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2994095\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=2870124\";s:2:\"1x\";s:68:\"https://ps.w.org/query-monitor/assets/banner-772x250.png?rev=2457098\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.6\";s:6:\"tested\";s:5:\"6.4.1\";s:12:\"requires_php\";s:3:\"7.4\";}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:1:{s:13:\"cmb2/init.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:18:\"w.org/plugins/cmb2\";s:4:\"slug\";s:4:\"cmb2\";s:6:\"plugin\";s:13:\"cmb2/init.php\";s:11:\"new_version\";s:6:\"2.10.1\";s:3:\"url\";s:35:\"https://wordpress.org/plugins/cmb2/\";s:7:\"package\";s:47:\"https://downloads.wordpress.org/plugin/cmb2.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:49:\"https://ps.w.org/cmb2/assets/icon.svg?rev=2866672\";s:3:\"svg\";s:49:\"https://ps.w.org/cmb2/assets/icon.svg?rev=2866672\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:60:\"https://ps.w.org/cmb2/assets/banner-1544x500.png?rev=2866672\";s:2:\"1x\";s:59:\"https://ps.w.org/cmb2/assets/banner-772x250.png?rev=2866672\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:5:\"3.8.0\";}}s:7:\"checked\";a:3:{s:13:\"cmb2/init.php\";s:6:\"2.10.1\";s:60:\"CMB2-field-Leaflet-Geocoder-master/cmb-field-leaflet-map.php\";s:5:\"0.1.3\";s:31:\"query-monitor/query-monitor.php\";s:6:\"3.12.2\";}}', 'no');

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_pmxi_files`
--

CREATE TABLE `ug_pmxi_files` (
  `id` bigint UNSIGNED NOT NULL,
  `import_id` bigint UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `path` text COLLATE utf8mb4_unicode_520_ci,
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_pmxi_hash`
--

CREATE TABLE `ug_pmxi_hash` (
  `hash` binary(16) NOT NULL,
  `post_id` bigint UNSIGNED NOT NULL,
  `import_id` smallint UNSIGNED NOT NULL,
  `post_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_pmxi_history`
--

CREATE TABLE `ug_pmxi_history` (
  `id` bigint UNSIGNED NOT NULL,
  `import_id` bigint UNSIGNED NOT NULL,
  `type` enum('manual','processing','trigger','continue','cli','') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `time_run` text COLLATE utf8mb4_unicode_520_ci,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `summary` text COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_pmxi_images`
--

CREATE TABLE `ug_pmxi_images` (
  `id` bigint UNSIGNED NOT NULL,
  `attachment_id` bigint UNSIGNED NOT NULL,
  `image_url` varchar(900) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image_filename` varchar(900) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_pmxi_imports`
--

CREATE TABLE `ug_pmxi_imports` (
  `id` bigint UNSIGNED NOT NULL,
  `parent_import_id` bigint NOT NULL DEFAULT '0',
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `friendly_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `feed_type` enum('xml','csv','zip','gz','') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` text COLLATE utf8mb4_unicode_520_ci,
  `xpath` text COLLATE utf8mb4_unicode_520_ci,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `root_element` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `processing` tinyint(1) NOT NULL DEFAULT '0',
  `executing` tinyint(1) NOT NULL DEFAULT '0',
  `triggered` tinyint(1) NOT NULL DEFAULT '0',
  `queue_chunk_number` bigint NOT NULL DEFAULT '0',
  `first_import` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `count` bigint NOT NULL DEFAULT '0',
  `imported` bigint NOT NULL DEFAULT '0',
  `created` bigint NOT NULL DEFAULT '0',
  `updated` bigint NOT NULL DEFAULT '0',
  `skipped` bigint NOT NULL DEFAULT '0',
  `deleted` bigint NOT NULL DEFAULT '0',
  `canceled` tinyint(1) NOT NULL DEFAULT '0',
  `canceled_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed` tinyint(1) NOT NULL DEFAULT '0',
  `failed_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `settings_update_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_activity` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `iteration` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_pmxi_posts`
--

CREATE TABLE `ug_pmxi_posts` (
  `id` bigint UNSIGNED NOT NULL,
  `post_id` bigint UNSIGNED NOT NULL,
  `import_id` bigint UNSIGNED NOT NULL,
  `unique_key` text COLLATE utf8mb4_unicode_520_ci,
  `product_key` text COLLATE utf8mb4_unicode_520_ci,
  `iteration` bigint NOT NULL DEFAULT '0',
  `specified` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_pmxi_templates`
--

CREATE TABLE `ug_pmxi_templates` (
  `id` bigint UNSIGNED NOT NULL,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `scheduled` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` text COLLATE utf8mb4_unicode_520_ci,
  `content` longtext COLLATE utf8mb4_unicode_520_ci,
  `is_keep_linebreaks` tinyint(1) NOT NULL DEFAULT '0',
  `is_leave_html` tinyint(1) NOT NULL DEFAULT '0',
  `fix_characters` tinyint(1) NOT NULL DEFAULT '0',
  `meta` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_postmeta`
--

CREATE TABLE `ug_postmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `post_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dump dei dati per la tabella `ug_postmeta`
--

INSERT INTO `ug_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 6, '_edit_lock', '1647098648:1'),
(4, 8, '_edit_lock', '1646590955:1'),
(5, 10, '_edit_lock', '1646591285:1'),
(8, 14, '_menu_item_type', 'post_type'),
(9, 14, '_menu_item_menu_item_parent', '0'),
(10, 14, '_menu_item_object_id', '10'),
(11, 14, '_menu_item_object', 'page'),
(12, 14, '_menu_item_target', ''),
(13, 14, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(14, 14, '_menu_item_xfn', ''),
(15, 14, '_menu_item_url', ''),
(17, 15, '_menu_item_type', 'post_type'),
(18, 15, '_menu_item_menu_item_parent', '0'),
(19, 15, '_menu_item_object_id', '8'),
(20, 15, '_menu_item_object', 'page'),
(21, 15, '_menu_item_target', ''),
(22, 15, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(23, 15, '_menu_item_xfn', ''),
(24, 15, '_menu_item_url', ''),
(26, 16, '_menu_item_type', 'post_type'),
(27, 16, '_menu_item_menu_item_parent', '0'),
(28, 16, '_menu_item_object_id', '6'),
(29, 16, '_menu_item_object', 'page'),
(30, 16, '_menu_item_target', ''),
(31, 16, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(32, 16, '_menu_item_xfn', ''),
(33, 16, '_menu_item_url', ''),
(36, 18, '_edit_lock', '1646601783:1'),
(46, 27, '_edit_lock', '1646602350:1'),
(47, 29, '_menu_item_type', 'post_type'),
(48, 29, '_menu_item_menu_item_parent', '0'),
(49, 29, '_menu_item_object_id', '27'),
(50, 29, '_menu_item_object', 'page'),
(51, 29, '_menu_item_target', ''),
(52, 29, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(53, 29, '_menu_item_xfn', ''),
(54, 29, '_menu_item_url', ''),
(56, 30, '_menu_item_type', 'post_type'),
(57, 30, '_menu_item_menu_item_parent', '0'),
(58, 30, '_menu_item_object_id', '18'),
(59, 30, '_menu_item_object', 'page'),
(60, 30, '_menu_item_target', ''),
(61, 30, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(62, 30, '_menu_item_xfn', ''),
(63, 30, '_menu_item_url', ''),
(66, 32, '_wp_attached_file', '2022/03/Schermata-da-2022-03-04-09-11-28.png'),
(67, 32, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1366;s:6:\"height\";i:768;s:4:\"file\";s:44:\"2022/03/Schermata-da-2022-03-04-09-11-28.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"Schermata-da-2022-03-04-09-11-28-300x169.png\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:45:\"Schermata-da-2022-03-04-09-11-28-1024x576.png\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"Schermata-da-2022-03-04-09-11-28-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"Schermata-da-2022-03-04-09-11-28-768x432.png\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(69, 34, '_edit_lock', '1700468533:1'),
(71, 34, '_edit_last', '1'),
(73, 37, '_wp_attached_file', '2022/03/logone.png'),
(74, 37, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:543;s:4:\"file\";s:18:\"2022/03/logone.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"logone-300x204.png\";s:5:\"width\";i:300;s:6:\"height\";i:204;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"logone-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"logone-768x521.png\";s:5:\"width\";i:768;s:6:\"height\";i:521;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(75, 34, '_thumbnail_id', '37'),
(76, 38, '_wp_attached_file', '2022/03/logo.png'),
(77, 38, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1006;s:6:\"height\";i:234;s:4:\"file\";s:16:\"2022/03/logo.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"logo-300x70.png\";s:5:\"width\";i:300;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"logo-768x179.png\";s:5:\"width\";i:768;s:6:\"height\";i:179;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(78, 39, '_edit_lock', '1646818952:1'),
(79, 40, '_menu_item_type', 'custom'),
(80, 40, '_menu_item_menu_item_parent', '0'),
(81, 40, '_menu_item_object_id', '40'),
(82, 40, '_menu_item_object', 'custom'),
(83, 40, '_menu_item_target', ''),
(84, 40, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(85, 40, '_menu_item_xfn', ''),
(86, 40, '_menu_item_url', '/'),
(88, 16, '_wp_old_date', '2022-03-06'),
(89, 15, '_wp_old_date', '2022-03-06'),
(90, 14, '_wp_old_date', '2022-03-06'),
(91, 41, '_wp_attached_file', '2022/03/salute-e1647094939986.jpg'),
(92, 41, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:600;s:4:\"file\";s:33:\"2022/03/salute-e1647094939986.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"salute-e1647094939986-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"salute-e1647094939986-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"salute-e1647094939986-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"salute-e1647094939986-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:34:\"salute-e1647094939986-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.3\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:13:\"Canon EOS 70D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"18\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:5:\"0.004\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(93, 41, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:10:\"salute.jpg\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:18:\"salute-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:18:\"salute-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:18:\"salute-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"large-orig\";a:4:{s:4:\"file\";s:19:\"salute-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"1536x1536-orig\";a:4:{s:4:\"file\";s:20:\"salute-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(94, 42, '_wp_attached_file', '2022/03/salute-1.jpg'),
(95, 42, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:20:\"2022/03/salute-1.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"salute-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"salute-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"salute-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"salute-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"salute-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.3\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:13:\"Canon EOS 70D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"18\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:5:\"0.004\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(96, 43, '_wp_attached_file', '2022/03/pizza-2000614_1920-e1647095337915.jpg'),
(97, 43, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:595;s:4:\"file\";s:45:\"2022/03/pizza-2000614_1920-e1647095337915.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"pizza-2000614_1920-e1647095337915-300x93.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:93;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:46:\"pizza-2000614_1920-e1647095337915-1024x317.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:317;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:45:\"pizza-2000614_1920-e1647095337915-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:45:\"pizza-2000614_1920-e1647095337915-768x238.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:238;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:46:\"pizza-2000614_1920-e1647095337915-1536x476.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:476;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(98, 44, '_wp_attached_file', '2022/03/pizza-2000614_1920-1.jpg'),
(99, 44, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:32:\"2022/03/pizza-2000614_1920-1.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"pizza-2000614_1920-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:33:\"pizza-2000614_1920-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"pizza-2000614_1920-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"pizza-2000614_1920-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:34:\"pizza-2000614_1920-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(100, 43, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:22:\"pizza-2000614_1920.jpg\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:30:\"pizza-2000614_1920-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:30:\"pizza-2000614_1920-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:30:\"pizza-2000614_1920-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"large-orig\";a:4:{s:4:\"file\";s:31:\"pizza-2000614_1920-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"1536x1536-orig\";a:4:{s:4:\"file\";s:32:\"pizza-2000614_1920-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(101, 45, '_wp_attached_file', '2022/03/hobbies-e1647095527436.jpg'),
(102, 45, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:600;s:4:\"file\";s:34:\"2022/03/hobbies-e1647095527436.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"hobbies-e1647095527436-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"hobbies-e1647095527436-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"hobbies-e1647095527436-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"hobbies-e1647095527436-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"hobbies-e1647095527436-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(103, 45, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1920;s:6:\"height\";i:1281;s:4:\"file\";s:11:\"hobbies.jpg\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:19:\"hobbies-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:19:\"hobbies-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:19:\"hobbies-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"large-orig\";a:4:{s:4:\"file\";s:20:\"hobbies-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"1536x1536-orig\";a:4:{s:4:\"file\";s:21:\"hobbies-1536x1025.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1025;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(104, 46, '_wp_attached_file', '2022/03/pronto-intervento-e1647095750847.jpg'),
(105, 46, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:600;s:4:\"file\";s:44:\"2022/03/pronto-intervento-e1647095750847.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"pronto-intervento-e1647095750847-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:45:\"pronto-intervento-e1647095750847-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"pronto-intervento-e1647095750847-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"pronto-intervento-e1647095750847-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:45:\"pronto-intervento-e1647095750847-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:13:\"Canon EOS 80D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"80\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(106, 47, '_wp_attached_file', '2022/03/pronto-intervento-1.jpg'),
(107, 47, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:31:\"2022/03/pronto-intervento-1.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"pronto-intervento-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"pronto-intervento-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"pronto-intervento-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"pronto-intervento-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:33:\"pronto-intervento-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:13:\"Canon EOS 80D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"80\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(108, 46, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:21:\"pronto-intervento.jpg\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:29:\"pronto-intervento-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:29:\"pronto-intervento-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:29:\"pronto-intervento-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"large-orig\";a:4:{s:4:\"file\";s:30:\"pronto-intervento-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"1536x1536-orig\";a:4:{s:4:\"file\";s:31:\"pronto-intervento-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(109, 48, '_wp_attached_file', '2022/03/professionisti.jpg'),
(110, 48, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:26:\"2022/03/professionisti.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"professionisti-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:27:\"professionisti-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"professionisti-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"professionisti-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:28:\"professionisti-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(111, 49, '_wp_attached_file', '2022/03/professionisti-1-e1647095944132.jpg'),
(112, 49, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:600;s:4:\"file\";s:43:\"2022/03/professionisti-1-e1647095944132.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:42:\"professionisti-1-e1647095944132-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"professionisti-1-e1647095944132-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"professionisti-1-e1647095944132-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"professionisti-1-e1647095944132-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:44:\"professionisti-1-e1647095944132-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(113, 49, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:20:\"professionisti-1.jpg\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:28:\"professionisti-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:28:\"professionisti-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:28:\"professionisti-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"large-orig\";a:4:{s:4:\"file\";s:29:\"professionisti-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"1536x1536-orig\";a:4:{s:4:\"file\";s:30:\"professionisti-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(114, 50, '_wp_attached_file', '2022/03/spesa.jpg'),
(115, 50, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:17:\"2022/03/spesa.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"spesa-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"spesa-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"spesa-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"spesa-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:19:\"spesa-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(116, 51, '_wp_attached_file', '2022/03/spesa-1-e1647096044219.jpg'),
(117, 51, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:600;s:4:\"file\";s:34:\"2022/03/spesa-1-e1647096044219.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"spesa-1-e1647096044219-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"spesa-1-e1647096044219-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"spesa-1-e1647096044219-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"spesa-1-e1647096044219-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"spesa-1-e1647096044219-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(118, 51, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:11:\"spesa-1.jpg\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:19:\"spesa-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:19:\"spesa-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:19:\"spesa-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"large-orig\";a:4:{s:4:\"file\";s:20:\"spesa-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"1536x1536-orig\";a:4:{s:4:\"file\";s:21:\"spesa-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(119, 52, '_wp_attached_file', '2022/03/sport.jpg'),
(120, 52, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:17:\"2022/03/sport.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"sport-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"sport-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"sport-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"sport-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:19:\"sport-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:20:\"Canon EOS 7D Mark II\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"182\";s:3:\"iso\";s:3:\"125\";s:13:\"shutter_speed\";s:6:\"0.0008\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(121, 53, '_wp_attached_file', '2022/03/sport-1-e1647096152654.jpg'),
(122, 53, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:600;s:4:\"file\";s:34:\"2022/03/sport-1-e1647096152654.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"sport-1-e1647096152654-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"sport-1-e1647096152654-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"sport-1-e1647096152654-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"sport-1-e1647096152654-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:35:\"sport-1-e1647096152654-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:20:\"Canon EOS 7D Mark II\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"182\";s:3:\"iso\";s:3:\"125\";s:13:\"shutter_speed\";s:6:\"0.0008\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(123, 53, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:11:\"sport-1.jpg\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:19:\"sport-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:19:\"sport-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:19:\"sport-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"large-orig\";a:4:{s:4:\"file\";s:20:\"sport-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"1536x1536-orig\";a:4:{s:4:\"file\";s:21:\"sport-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(124, 54, '_wp_attached_file', '2022/03/studio.jpg'),
(125, 54, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:18:\"2022/03/studio.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"studio-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"studio-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"studio-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"studio-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:20:\"studio-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(126, 55, '_wp_attached_file', '2022/03/studio-1-e1647096299687.jpg'),
(127, 55, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:600;s:4:\"file\";s:35:\"2022/03/studio-1-e1647096299687.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"studio-1-e1647096299687-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:36:\"studio-1-e1647096299687-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"studio-1-e1647096299687-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"studio-1-e1647096299687-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"studio-1-e1647096299687-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(128, 55, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:12:\"studio-1.jpg\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:20:\"studio-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:20:\"studio-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:20:\"studio-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"large-orig\";a:4:{s:4:\"file\";s:21:\"studio-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"1536x1536-orig\";a:4:{s:4:\"file\";s:22:\"studio-1-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(162, 92, '_edit_lock', '1683965883:1'),
(163, 92, '_edit_last', '1'),
(164, 92, '_attivita_meta_data_tipologia', 'attcomm'),
(165, 92, '_attivita_meta_data_descrizione_breve', 'saasc'),
(166, 92, '_attivita_meta_data_indirizzo', 'Traversa salviense 2/A'),
(167, 92, '_attivita_meta_data_posizione_gps', 'a:2:{s:3:\"lat\";s:10:\"43.1966085\";s:3:\"lng\";s:10:\"13.3765707\";}'),
(168, 92, '_attivita_meta_data_cap', '62010'),
(169, 92, '_attivita_meta_data_email', 'emanuele.ferrarini@gmail.com'),
(170, 92, '_attivita_meta_data_telefono', '3389723259'),
(171, 34, '_attivita_meta_data_indirizzo', 'Via Roma'),
(172, 34, '_attivita_meta_data_posizione_gps', 'a:2:{s:3:\"lat\";s:17:\"43.19608792693196\";s:3:\"lng\";s:18:\"13.376696705818178\";}');

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_posts`
--

CREATE TABLE `ug_posts` (
  `ID` bigint UNSIGNED NOT NULL,
  `post_author` bigint UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dump dei dati per la tabella `ug_posts`
--

INSERT INTO `ug_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(2, 1, '2022-03-06 19:13:39', '2022-03-06 18:13:39', '<!-- wp:paragraph -->\n<p>Questa è una pagina di esempio. Differisce da un articolo di un blog perché rimane sempre allo stesso posto e (in molti temi) appare nel menu di navigazione. Molte persone iniziano con una pagina di Informazioni che li presentano ai visitatori del sito. Potrebbe apparire una presentazione del tipo:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Ciao! Sono un fattorino ciclista di giorno, aspirante attore di notte e questo è il mio sito web. Vivo a Los Angeles, ho un grande cane di nome Jack e mi piace la piña colada. (E prendere la pioggia)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...o qualcosa di simile:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>La Società XYZ Aggeggi è stata fondata nel 1971 e da allora fornisce al pubblico aggeggi di ottima qualità. Situata a Fantasilandia, XYZ impiega oltre 2.000 persone e realizza ogni sorta di aggeggio fantastico per la comunità di Fantasilandia.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Come nuovo utente di WordPress, dovresti andare nella tua <a href=\"http://urbigialla.com/wp-admin/\">Bacheca</a> per eliminare questa pagina, e crearne delle nuove per i tuoi contenuti. Divertiti!</p>\n<!-- /wp:paragraph -->', 'Pagina di esempio', '', 'publish', 'closed', 'open', '', 'pagina-di-esempio', '', '', '2022-03-06 19:13:39', '2022-03-06 18:13:39', '', 0, 'http://urbigialla.com/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-03-06 19:13:39', '2022-03-06 18:13:39', '<!-- wp:heading --><h2>Chi siamo</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>L\'indirizzo del nostro sito web è: http://urbigialla.com.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Commenti</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>Quando i visitatori lasciano commenti sul sito, raccogliamo i dati mostrati nel modulo dei commenti oltre all\'indirizzo IP del visitatore e la stringa dello user agent del browser per facilitare il rilevamento dello spam.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Una stringa anonimizzata creata a partire dal tuo indirizzo email (altrimenti detta hash) può essere fornita al servizio Gravatar per vedere se lo stai usando. La privacy policy del servizio Gravatar è disponibile qui: https://automattic.com/privacy/. Dopo l\'approvazione del tuo commento, la tua immagine del profilo è visibile al pubblico nel contesto del tuo commento.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>Se carichi immagini sul sito web, dovresti evitare di caricare immagini che includono i dati di posizione incorporati (EXIF GPS). I visitatori del sito web possono scaricare ed estrarre qualsiasi dato sulla posizione dalle immagini sul sito web.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookie</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>Se lasci un commento sul nostro sito, puoi scegliere di salvare il tuo nome, indirizzo email e sito web nei cookie. Sono usati per la tua comodità in modo che tu non debba inserire nuovamente i tuoi dati quando lasci un altro commento. Questi cookie dureranno per un anno.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se visiti la pagina di login, verrà impostato un cookie temporaneo per determinare se il tuo browser accetta i cookie. Questo cookie non contiene dati personali e viene eliminato quando chiudi il browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Quando effettui l\'accesso, verranno impostati diversi cookie per salvare le tue informazioni di accesso e le tue opzioni di visualizzazione dello schermo. I cookie di accesso durano due giorni mentre i cookie per le opzioni dello schermo durano un anno. Se selezioni &quot;Ricordami&quot;, il tuo accesso persisterà per due settimane. Se esci dal tuo account, i cookie di accesso verranno rimossi.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se modifichi o pubblichi un articolo, un cookie aggiuntivo verrà salvato nel tuo browser. Questo cookie non include dati personali, ma indica semplicemente l\'ID dell\'articolo appena modificato. Scade dopo 1 giorno.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Contenuto incorporato da altri siti web</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>Gli articoli su questo sito possono includere contenuti incorporati (ad esempio video, immagini, articoli, ecc.). I contenuti incorporati da altri siti web si comportano esattamente allo stesso modo come se il visitatore avesse visitato l\'altro sito web.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Questi siti web possono raccogliere dati su di te, usare cookie, integrare ulteriori tracciamenti di terze parti e monitorare l\'interazione con essi, incluso il tracciamento della tua interazione con il contenuto incorporato se hai un account e sei connesso a quei siti web.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Con chi condividiamo i tuoi dati</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>Se richiedi una reimpostazione della password, il tuo indirizzo IP verrà incluso nell\'email di reimpostazione.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Per quanto tempo conserviamo i tuoi dati</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>Se lasci un commento, il commento e i relativi metadati vengono conservati a tempo indeterminato. È così che possiamo riconoscere e approvare automaticamente eventuali commenti successivi invece di tenerli in una coda di moderazione.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Per gli utenti che si registrano sul nostro sito web (se presenti), memorizziamo anche le informazioni personali che forniscono nel loro profilo utente. Tutti gli utenti possono vedere, modificare o cancellare le loro informazioni personali in qualsiasi momento (eccetto il loro nome utente che non possono cambiare). Gli amministratori del sito web possono anche vedere e modificare queste informazioni.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Quali diritti hai sui tuoi dati</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>Se hai un account su questo sito, o hai lasciato commenti, puoi richiedere di ricevere un file esportato dal sito con i dati personali che abbiamo su di te, compresi i dati che ci hai fornito. Puoi anche richiedere che cancelliamo tutti i dati personali che ti riguardano. Questo non include i dati che siamo obbligati a conservare per scopi amministrativi, legali o di sicurezza.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Dove spediamo i tuoi dati</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Testo suggerito: </strong>I commenti dei visitatori possono essere controllati attraverso un servizio di rilevamento automatico dello spam.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-03-06 19:13:39', '2022-03-06 18:13:39', '', 0, 'http://urbigialla.com/?page_id=3', 0, 'page', '', 0),
(5, 1, '2022-03-06 19:14:09', '2022-03-06 18:14:09', '{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentytwo', '', '', '2022-03-06 19:14:09', '2022-03-06 18:14:09', '', 0, 'http://urbigialla.com/2022/03/06/wp-global-styles-twentytwentytwo/', 0, 'wp_global_styles', '', 0),
(6, 1, '2022-03-06 19:24:36', '2022-03-06 18:24:36', '<!-- wp:paragraph -->\n<p>Urbigialla nasce per dare a tutti coloro che vivono Urbisaglia un prontuario di numeri utili e informazioni sulle attività che rendono il nostro paese un ambiente vivo.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>E\' possibile trovare le informazioni sui professionisti di Urbisaglia o che vi lavorano, ma anche sulle attività delle molte associazioni che animano il nostro paese.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Al tempo stesso è possibile trovare le informazioni sul più vicino punto di raccolta dei rifiuti... bla bla bla</p>\n<!-- /wp:paragraph -->', 'Il progetto', '', 'publish', 'closed', 'closed', '', 'il-progetto', '', '', '2022-03-12 16:26:32', '2022-03-12 15:26:32', '', 0, 'http://urbigialla.com/?page_id=6', 0, 'page', '', 0),
(7, 1, '2022-03-06 19:24:36', '2022-03-06 18:24:36', '', 'Il progetto', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-03-06 19:24:36', '2022-03-06 18:24:36', '', 6, 'http://urbigialla.com/?p=7', 0, 'revision', '', 0),
(8, 1, '2022-03-06 19:24:56', '2022-03-06 18:24:56', '', 'Intorno a te', '', 'publish', 'closed', 'closed', '', 'intorno-a-te', '', '', '2022-03-06 19:24:56', '2022-03-06 18:24:56', '', 0, 'http://urbigialla.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2022-03-06 19:24:56', '2022-03-06 18:24:56', '', 'Intorno a te', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2022-03-06 19:24:56', '2022-03-06 18:24:56', '', 8, 'http://urbigialla.com/?p=9', 0, 'revision', '', 0),
(10, 1, '2022-03-06 19:25:06', '2022-03-06 18:25:06', '', 'Partecipa', '', 'publish', 'closed', 'closed', '', 'partecipa', '', '', '2022-03-06 19:28:58', '2022-03-06 18:28:58', '', 0, 'http://urbigialla.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2022-03-06 19:25:06', '2022-03-06 18:25:06', '', 'Partecipa', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2022-03-06 19:25:06', '2022-03-06 18:25:06', '', 10, 'http://urbigialla.com/?p=11', 0, 'revision', '', 0),
(12, 1, '2022-03-06 19:28:00', '2022-03-06 18:28:00', '', 'Partecipa', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2022-03-06 19:28:00', '2022-03-06 18:28:00', '', 10, 'http://urbigialla.com/?p=12', 0, 'revision', '', 0),
(14, 1, '2022-03-10 19:06:01', '2022-03-06 21:24:55', ' ', '', '', 'publish', 'closed', 'closed', '', '14', '', '', '2022-03-10 19:06:01', '2022-03-10 18:06:01', '', 0, 'http://urbigialla.com/?p=14', 4, 'nav_menu_item', '', 0),
(15, 1, '2022-03-10 19:06:01', '2022-03-06 21:24:55', ' ', '', '', 'publish', 'closed', 'closed', '', '15', '', '', '2022-03-10 19:06:01', '2022-03-10 18:06:01', '', 0, 'http://urbigialla.com/?p=15', 3, 'nav_menu_item', '', 0),
(16, 1, '2022-03-10 19:06:01', '2022-03-06 21:24:55', ' ', '', '', 'publish', 'closed', 'closed', '', '16', '', '', '2022-03-10 19:06:01', '2022-03-10 18:06:01', '', 0, 'http://urbigialla.com/?p=16', 2, 'nav_menu_item', '', 0),
(18, 1, '2022-03-06 22:25:14', '2022-03-06 21:25:14', '', 'Cookies', '', 'publish', 'closed', 'closed', '', 'cookies', '', '', '2022-03-06 22:25:26', '2022-03-06 21:25:26', '', 0, 'http://urbigialla.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2022-03-06 22:25:04', '2022-03-06 21:25:04', '{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-urbigialla', '', '', '2022-03-06 22:25:04', '2022-03-06 21:25:04', '', 0, 'http://urbigialla.com/2022/03/06/wp-global-styles-urbigialla/', 0, 'wp_global_styles', '', 0),
(20, 1, '2022-03-06 22:25:04', '2022-03-06 21:25:04', '{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-urbigialla', '', '', '2022-03-06 22:25:04', '2022-03-06 21:25:04', '', 0, 'http://urbigialla.com/2022/03/06/wp-global-styles-urbigialla/', 0, 'wp_global_styles', '', 0),
(21, 1, '2022-03-06 22:25:14', '2022-03-06 21:25:14', '', 'Cookies', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2022-03-06 22:25:14', '2022-03-06 21:25:14', '', 18, 'http://urbigialla.com/?p=21', 0, 'revision', '', 0),
(22, 1, '2022-03-06 22:25:19', '2022-03-06 21:25:19', '', 'Privacy', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2022-03-06 22:25:19', '2022-03-06 21:25:19', '', 18, 'http://urbigialla.com/?p=22', 0, 'revision', '', 0),
(23, 1, '2022-03-06 22:25:26', '2022-03-06 21:25:26', '', 'Cookies', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2022-03-06 22:25:26', '2022-03-06 21:25:26', '', 18, 'http://urbigialla.com/?p=23', 0, 'revision', '', 0),
(27, 1, '2022-03-06 22:26:10', '2022-03-06 21:26:10', '', 'Privacy', '', 'publish', 'closed', 'closed', '', 'privacy', '', '', '2022-03-06 22:26:10', '2022-03-06 21:26:10', '', 0, 'http://urbigialla.com/?page_id=27', 0, 'page', '', 0),
(28, 1, '2022-03-06 22:26:10', '2022-03-06 21:26:10', '', 'Privacy', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2022-03-06 22:26:10', '2022-03-06 21:26:10', '', 27, 'http://urbigialla.com/?p=28', 0, 'revision', '', 0),
(29, 1, '2022-03-06 22:26:28', '2022-03-06 21:26:28', ' ', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2022-03-06 22:26:28', '2022-03-06 21:26:28', '', 0, 'http://urbigialla.com/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2022-03-06 22:26:28', '2022-03-06 21:26:28', ' ', '', '', 'publish', 'closed', 'closed', '', '30', '', '', '2022-03-06 22:26:28', '2022-03-06 21:26:28', '', 0, 'http://urbigialla.com/?p=30', 2, 'nav_menu_item', '', 0),
(32, 1, '2022-03-07 08:13:37', '2022-03-07 07:13:37', '', 'Schermata da 2022-03-04 09-11-28', '', 'inherit', 'open', 'closed', '', 'schermata-da-2022-03-04-09-11-28', '', '', '2022-03-07 08:13:37', '2022-03-07 07:13:37', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/Schermata-da-2022-03-04-09-11-28.png', 0, 'attachment', 'image/png', 0),
(34, 1, '2022-03-08 21:35:06', '2022-03-08 20:35:06', '<!-- wp:heading {\"level\":1} -->\n<h1 class=\"wp-block-heading\">Melior fluminaque premuntur temperiemque circumfluus</h1>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Indigestaque carmen onerosior onus totidem. Mixtam aliis carentem dissaepserat tollere caelo forma. Perveniunt nullus nova poena habendum quinta. Cornua inmensa. Iunctarum et certis frigida certis tepescunt fuerat aquae. Undae diverso undae. Aurea usu. Boreas distinxit capacius ambitae iudicis militis terrarum solidumque fontes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Sanctius sua inposuit carmen limitibus</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">Dextra rerum pressa caeca videre</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":4} -->\n<h4 class=\"wp-block-heading\">Terram pendebat astra lapidosos vesper</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Piscibus possedit ne faecis caelum prima. Vesper hanc. Cetera effervescere gravitate! Deducite quisque nubes aethere sua cinxit margine cetera. Dominari quem caecoque imagine caelo. Quisque nubes nix undae rapidisque cuncta pace coercuit ut. Evolvit umor aquae traxit retinebat manebat passim fidem.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Flexi caelum cesserunt terrarum ita temperiemque sectamque dixere flamina iussit congestaque margine non satus</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Vindice hanc traxit undas locoque orbem mutastis freta natura aquae porrexerat arce permisit</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Iapeto adsiduis summaque norant ab cesserunt videre duris aequalis ulla bene iunctarum summaque</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Margine nulli quicquam ignea litem sinistra locavit recens sectamque cognati aere recens oppida undas terra erant convexi</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Poena rerum quanto metusque sponte lapidosos cornua. Triones retinebat tractu. Sibi umentia ne fuit pluviaque. Mutatas dissociata duae scythiam partim obsistitur ab. Caelum fulminibus tellus proximus bracchia possedit securae tellus sunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list {\"ordered\":true} -->\n<ol><!-- wp:list-item -->\n<li>Mutastis illi rectumque amphitrite addidit nebulas securae quisquis prima suis aliis ita frigida sublime toto dissociata adspirate eodem undis gentes rapidisque mundo auroram ora sibi</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Galeae nullus regna nondum pluvialibus orbis moles moles legebantur dispositam pondus secrevit posset: tellus discordia austro valles dei pondus</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Litora usu principio utque numero locis pronaque pulsant dedit frigore diu litem lacusque umentia volucres alto mundo diversa pressa recepta recens quarum caelumque emicuit</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Tegi eodem nuper nunc rerum hunc cuncta sine siccis fert ignotas viseret discordia fronde hominum tepescunt</li>\n<!-- /wp:list-item --></ol>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Quam non duas. Sorbentur calidis non temperiemque densior oppida. Animalia tanto plagae convexi vesper. Lanient secrevit mixtam nix prima uno. Pendebat animal oppida austro flamma inposuit pace. Liberioris totidemque fabricator fabricator proxima. Hominum sanctius congeriem cognati cesserunt obsistitur tegi.</p>\n<!-- /wp:paragraph -->', 'GN - i 7 artigiani', '', 'publish', 'closed', 'closed', '', 'gn-i-7-artigiani', '', '', '2023-11-18 11:09:51', '2023-11-18 10:09:51', '', 0, 'http://urbigialla.com/?post_type=attivita&#038;p=34', 0, 'attivita', '', 0),
(36, 1, '2022-03-08 21:35:06', '2022-03-08 20:35:06', '', 'GN - i 7 artigiani', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2022-03-08 21:35:06', '2022-03-08 20:35:06', '', 34, 'http://urbigialla.com/?p=36', 0, 'revision', '', 0),
(37, 1, '2022-03-08 21:47:04', '2022-03-08 20:47:04', '', 'logone', '', 'inherit', 'open', 'closed', '', 'logone', '', '', '2022-03-08 21:47:04', '2022-03-08 20:47:04', '', 34, 'http://urbigialla.com/wp-content/uploads/2022/03/logone.png', 0, 'attachment', 'image/png', 0),
(38, 1, '2022-03-08 22:27:46', '2022-03-08 21:27:46', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2022-03-08 22:27:46', '2022-03-08 21:27:46', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/logo.png', 0, 'attachment', 'image/png', 0),
(39, 1, '2022-03-08 22:29:00', '0000-00-00 00:00:00', '<!-- wp:image {\"id\":38,\"sizeSlug\":\"medium\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-medium\"><img src=\"http://urbigialla.com/wp-content/uploads/2022/03/logo-300x70.png\" alt=\"\" class=\"wp-image-38\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '', '', 'draft', 'open', 'open', '', '', '', '', '2022-03-08 22:29:00', '2022-03-08 21:29:00', '', 0, 'http://urbigialla.com/?p=39', 0, 'post', '', 0),
(40, 1, '2022-03-10 19:06:01', '2022-03-10 18:06:01', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-03-10 19:06:01', '2022-03-10 18:06:01', '', 0, 'http://urbigialla.com/?p=40', 1, 'nav_menu_item', '', 0),
(41, 1, '2022-03-12 15:21:29', '2022-03-12 14:21:29', '', 'salute', '', 'inherit', 'open', 'closed', '', 'salute', '', '', '2022-03-12 15:21:29', '2022-03-12 14:21:29', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/salute.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2022-03-12 15:22:27', '2022-03-12 14:22:27', '', 'salute', '', 'inherit', 'open', 'closed', '', 'salute-2', '', '', '2022-03-12 15:22:27', '2022-03-12 14:22:27', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/salute-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2022-03-12 15:28:10', '2022-03-12 14:28:10', '', 'mangiare-dormire-intestazione', '', 'inherit', 'open', 'closed', '', 'pizza-2000614_1920', '', '', '2022-03-12 15:29:16', '2022-03-12 14:29:16', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/pizza-2000614_1920.jpg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2022-03-12 15:28:12', '2022-03-12 14:28:12', '', 'mangiare-dormire', '', 'inherit', 'open', 'closed', '', 'pizza-2000614_1920-2', '', '', '2022-03-12 15:29:22', '2022-03-12 14:29:22', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/pizza-2000614_1920-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2022-03-12 15:31:16', '2022-03-12 14:31:16', '', 'hobbies intestazione', '', 'inherit', 'open', 'closed', '', 'hobbies', '', '', '2022-03-12 15:32:15', '2022-03-12 14:32:15', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/hobbies.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2022-03-12 15:35:29', '2022-03-12 14:35:29', '', 'pronto-intervento-intestazione', '', 'inherit', 'open', 'closed', '', 'pronto-intervento', '', '', '2022-03-12 15:36:00', '2022-03-12 14:36:00', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/pronto-intervento.jpg', 0, 'attachment', 'image/jpeg', 0),
(47, 1, '2022-03-12 15:35:31', '2022-03-12 14:35:31', '', 'pronto-intervento', '', 'inherit', 'open', 'closed', '', 'pronto-intervento-2', '', '', '2022-03-12 15:35:31', '2022-03-12 14:35:31', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/pronto-intervento-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2022-03-12 15:38:34', '2022-03-12 14:38:34', '', 'professionisti', '', 'inherit', 'open', 'closed', '', 'professionisti', '', '', '2022-03-12 15:38:34', '2022-03-12 14:38:34', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/professionisti.jpg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2022-03-12 15:38:40', '2022-03-12 14:38:40', '', 'professionisti', '', 'inherit', 'open', 'closed', '', 'professionisti-2', '', '', '2022-03-12 15:38:40', '2022-03-12 14:38:40', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/professionisti-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2022-03-12 15:40:03', '2022-03-12 14:40:03', '', 'spesa', '', 'inherit', 'open', 'closed', '', 'spesa', '', '', '2022-03-12 15:40:03', '2022-03-12 14:40:03', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/spesa.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2022-03-12 15:40:05', '2022-03-12 14:40:05', '', 'spesa-intestazione', '', 'inherit', 'open', 'closed', '', 'spesa-2', '', '', '2022-03-12 15:40:12', '2022-03-12 14:40:12', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/spesa-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2022-03-12 15:42:05', '2022-03-12 14:42:05', '', 'sport', '', 'inherit', 'open', 'closed', '', 'sport', '', '', '2022-03-12 15:42:05', '2022-03-12 14:42:05', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/sport.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2022-03-12 15:42:15', '2022-03-12 14:42:15', '', 'sport', '', 'inherit', 'open', 'closed', '', 'sport-2', '', '', '2022-03-12 15:42:15', '2022-03-12 14:42:15', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/sport-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2022-03-12 15:44:25', '2022-03-12 14:44:25', '', 'studio', '', 'inherit', 'open', 'closed', '', 'studio', '', '', '2022-03-12 15:44:25', '2022-03-12 14:44:25', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/studio.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2022-03-12 15:44:33', '2022-03-12 14:44:33', '', 'studio', '', 'inherit', 'open', 'closed', '', 'studio-2', '', '', '2022-03-12 15:44:33', '2022-03-12 14:44:33', '', 0, 'http://urbigialla.com/wp-content/uploads/2022/03/studio-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2022-03-12 16:26:32', '2022-03-12 15:26:32', '<!-- wp:paragraph -->\n<p>Urbigialla nasce per dare a tutti coloro che vivono Urbisaglia un prontuario di numeri utili e informazioni sulle attività che rendono il nostro paese un ambiente vivo.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>E\' possibile trovare le informazioni sui professionisti di Urbisaglia o che vi lavorano, ma anche sulle attività delle molte associazioni che animano il nostro paese.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Al tempo stesso è possibile trovare le informazioni sul più vicino punto di raccolta dei rifiuti... bla bla bla</p>\n<!-- /wp:paragraph -->', 'Il progetto', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-03-12 16:26:32', '2022-03-12 15:26:32', '', 6, 'http://urbigialla.com/?p=56', 0, 'revision', '', 0),
(61, 1, '2022-07-26 12:24:54', '2022-07-26 10:24:54', '<!-- wp:heading {\"level\":1} -->\n<h1>Melior fluminaque premuntur temperiemque circumfluus</h1>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Indigestaque carmen onerosior onus totidem. Mixtam aliis carentem dissaepserat tollere caelo forma. Perveniunt nullus nova poena habendum quinta. Cornua inmensa. Iunctarum et certis frigida certis tepescunt fuerat aquae. Undae diverso undae. Aurea usu. Boreas distinxit capacius ambitae iudicis militis terrarum solidumque fontes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Sanctius sua inposuit carmen limitibus</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Dextra rerum pressa caeca videre</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":4} -->\n<h4>Terram pendebat astra lapidosos vesper</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Piscibus possedit ne faecis caelum prima. Vesper hanc. Cetera effervescere gravitate! Deducite quisque nubes aethere sua cinxit margine cetera. Dominari quem caecoque imagine caelo. Quisque nubes nix undae rapidisque cuncta pace coercuit ut. Evolvit umor aquae traxit retinebat manebat passim fidem.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>Flexi caelum cesserunt terrarum ita temperiemque sectamque dixere flamina iussit congestaque margine non satus</li><li>Vindice hanc traxit undas locoque orbem mutastis freta natura aquae porrexerat arce permisit</li><li>Iapeto adsiduis summaque norant ab cesserunt videre duris aequalis ulla bene iunctarum summaque</li><li>Margine nulli quicquam ignea litem sinistra locavit recens sectamque cognati aere recens oppida undas terra erant convexi</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Poena rerum quanto metusque sponte lapidosos cornua. Triones retinebat tractu. Sibi umentia ne fuit pluviaque. Mutatas dissociata duae scythiam partim obsistitur ab. Caelum fulminibus tellus proximus bracchia possedit securae tellus sunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list {\"ordered\":true} -->\n<ol><li>Mutastis illi rectumque amphitrite addidit nebulas securae quisquis prima suis aliis ita frigida sublime toto dissociata adspirate eodem undis gentes rapidisque mundo auroram ora sibi</li><li>Galeae nullus regna nondum pluvialibus orbis moles moles legebantur dispositam pondus secrevit posset: tellus discordia austro valles dei pondus</li><li>Litora usu principio utque numero locis pronaque pulsant dedit frigore diu litem lacusque umentia volucres alto mundo diversa pressa recepta recens quarum caelumque emicuit</li><li>Tegi eodem nuper nunc rerum hunc cuncta sine siccis fert ignotas viseret discordia fronde hominum tepescunt</li></ol>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Quam non duas. Sorbentur calidis non temperiemque densior oppida. Animalia tanto plagae convexi vesper. Lanient secrevit mixtam nix prima uno. Pendebat animal oppida austro flamma inposuit pace. Liberioris totidemque fabricator fabricator proxima. Hominum sanctius congeriem cognati cesserunt obsistitur tegi.</p>\n<!-- /wp:paragraph -->', 'GN - i 7 artigiani', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2022-07-26 12:24:54', '2022-07-26 10:24:54', '', 34, 'http://urbigialla.com/?p=61', 0, 'revision', '', 0),
(89, 1, '2023-05-06 12:05:50', '2023-05-06 10:05:50', '<!-- wp:heading {\"level\":1} -->\n<h1 class=\"wp-block-heading\">Melior fluminaque premuntur temperiemque circumfluus</h1>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Indigestaque carmen onerosior onus totidem. Mixtam aliis carentem dissaepserat tollere caelo forma. Perveniunt nullus nova poena habendum quinta. Cornua inmensa. Iunctarum et certis frigida certis tepescunt fuerat aquae. Undae diverso undae. Aurea usu. Boreas distinxit capacius ambitae iudicis militis terrarum solidumque fontes.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Sanctius sua inposuit carmen limitibus</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">Dextra rerum pressa caeca videre</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":4} -->\n<h4 class=\"wp-block-heading\">Terram pendebat astra lapidosos vesper</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Piscibus possedit ne faecis caelum prima. Vesper hanc. Cetera effervescere gravitate! Deducite quisque nubes aethere sua cinxit margine cetera. Dominari quem caecoque imagine caelo. Quisque nubes nix undae rapidisque cuncta pace coercuit ut. Evolvit umor aquae traxit retinebat manebat passim fidem.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Flexi caelum cesserunt terrarum ita temperiemque sectamque dixere flamina iussit congestaque margine non satus</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Vindice hanc traxit undas locoque orbem mutastis freta natura aquae porrexerat arce permisit</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Iapeto adsiduis summaque norant ab cesserunt videre duris aequalis ulla bene iunctarum summaque</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Margine nulli quicquam ignea litem sinistra locavit recens sectamque cognati aere recens oppida undas terra erant convexi</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Poena rerum quanto metusque sponte lapidosos cornua. Triones retinebat tractu. Sibi umentia ne fuit pluviaque. Mutatas dissociata duae scythiam partim obsistitur ab. Caelum fulminibus tellus proximus bracchia possedit securae tellus sunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list {\"ordered\":true} -->\n<ol><!-- wp:list-item -->\n<li>Mutastis illi rectumque amphitrite addidit nebulas securae quisquis prima suis aliis ita frigida sublime toto dissociata adspirate eodem undis gentes rapidisque mundo auroram ora sibi</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Galeae nullus regna nondum pluvialibus orbis moles moles legebantur dispositam pondus secrevit posset: tellus discordia austro valles dei pondus</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Litora usu principio utque numero locis pronaque pulsant dedit frigore diu litem lacusque umentia volucres alto mundo diversa pressa recepta recens quarum caelumque emicuit</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Tegi eodem nuper nunc rerum hunc cuncta sine siccis fert ignotas viseret discordia fronde hominum tepescunt</li>\n<!-- /wp:list-item --></ol>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Quam non duas. Sorbentur calidis non temperiemque densior oppida. Animalia tanto plagae convexi vesper. Lanient secrevit mixtam nix prima uno. Pendebat animal oppida austro flamma inposuit pace. Liberioris totidemque fabricator fabricator proxima. Hominum sanctius congeriem cognati cesserunt obsistitur tegi.</p>\n<!-- /wp:paragraph -->', 'GN - i 7 artigiani', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2023-05-06 12:05:50', '2023-05-06 10:05:50', '', 34, 'http://urbigialla.com/?p=89', 0, 'revision', '', 0),
(92, 1, '2023-05-13 10:18:02', '2023-05-13 08:18:02', '', 'Poffarbacco', '', 'publish', 'closed', 'closed', '', 'poffarbacco', '', '', '2023-05-13 10:18:03', '2023-05-13 08:18:03', '', 0, 'http://urbigialla.com/?post_type=attivita&#038;p=92', 0, 'attivita', '', 0),
(93, 1, '2023-05-13 10:18:02', '2023-05-13 08:18:02', '', 'Poffarbacco', '', 'inherit', 'closed', 'closed', '', '92-revision-v1', '', '', '2023-05-13 10:18:02', '2023-05-13 08:18:02', '', 92, 'http://urbigialla.com/?p=93', 0, 'revision', '', 0),
(94, 1, '2023-11-18 11:00:35', '0000-00-00 00:00:00', '', 'Bozza automatica', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-11-18 11:00:35', '0000-00-00 00:00:00', '', 0, 'http://urbigialla.com/?p=94', 0, 'post', '', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_termmeta`
--

CREATE TABLE `ug_termmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_terms`
--

CREATE TABLE `ug_terms` (
  `term_id` bigint UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dump dei dati per la tabella `ug_terms`
--

INSERT INTO `ug_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Senza categoria', 'senza-categoria', 0),
(2, 'twentytwentytwo', 'twentytwentytwo', 0),
(3, 'Superiore', 'superiore', 0),
(4, 'urbigialla', 'urbigialla', 0),
(6, 'Inferiore', 'inferiore', 0),
(8, 'Mangiare e Dormire', 'mangiare-e-dormire', 0),
(9, 'Piazza garibaldi', 'piazza-garibaldi', 0),
(10, 'Salute', 'salute', 0),
(11, 'Hobbies', 'hobbies', 0),
(12, 'Pronto intervento', 'pronto-intervento', 0),
(13, 'Spesa', 'spesa', 0),
(14, 'Sport', 'sport', 0),
(15, 'Studio', 'studio', 0),
(16, 'Professionisti', 'professionisti', 0),
(17, 'Bed and breakfast', 'bed-and-breakfast', 0),
(18, 'Case vacanze', 'case-vacanze', 0),
(19, 'Affittacamere', 'affittacamere', 0),
(20, 'Ostelli', 'ostelli', 0),
(21, 'Aperitivi', 'aperitivi', 0),
(22, 'Bar', 'bar', 0),
(23, 'Gastronomia', 'gastronomia', 0),
(24, 'Gelateria', 'gelateria', 0),
(25, 'Apicoltore', 'apicoltore', 0),
(26, 'Aziende agricole', 'aziende-agricole', 0),
(27, 'Supermercato', 'supermercato', 0),
(28, 'Frutta e verdura', 'frutta-e-verdura', 0),
(29, 'Pane e pizza', 'pane-e-pizza', 0),
(30, 'Pizzeria', 'pizzeria', 0),
(31, 'Ristorante', 'ristorante', 0),
(32, 'Prodotti a km 0', 'prodotti-a-km-0', 0),
(33, 'Prodotti biologici', 'prodotti-biologici', 0),
(34, 'Prodotti agricoli', 'prodotti-agricoli', 0),
(35, 'Prodotti per l\'igiene', 'prodotti-per-ligiene', 0),
(36, 'Rosticceria', 'rosticceria', 0),
(37, 'Surgelati', 'surgelati', 0),
(38, 'Torte decorate', 'torte-decorate', 0),
(39, 'Vino sfuso', 'vino-sfuso', 0),
(40, 'Alimenti per animali', 'alimenti-per-animali', 0),
(41, 'Alimenti per diabetici', 'alimenti-per-diabetici', 0),
(42, 'Caffetteria', 'caffetteria', 0),
(43, 'Avis', 'avis', 0),
(44, 'Dentista', 'dentista', 0),
(45, 'Medico di famiglia', 'medico-di-famiglia', 0),
(46, 'Farmacie', 'farmacie', 0),
(47, 'Guardia medica', 'guardia-medica', 0),
(48, 'Scuole secondarie di I grado', 'scuole-secondarie-di-i-grado', 0),
(49, 'Scuole primarie', 'scuole-primarie', 0),
(50, 'Scuole dell\'infanzia', 'scuole-dellinfanzia', 0),
(51, 'Asilo nido', 'asilo-nido', 0),
(52, 'Scuola di musica', 'scuola-di-musica', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_term_relationships`
--

CREATE TABLE `ug_term_relationships` (
  `object_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dump dei dati per la tabella `ug_term_relationships`
--

INSERT INTO `ug_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(5, 2, 0),
(14, 3, 0),
(15, 3, 0),
(16, 3, 0),
(19, 4, 0),
(20, 4, 0),
(29, 6, 0),
(30, 6, 0),
(34, 9, 0),
(34, 21, 0),
(34, 22, 0),
(34, 29, 0),
(34, 32, 0),
(39, 1, 0),
(40, 3, 0),
(92, 8, 0),
(92, 19, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_term_taxonomy`
--

CREATE TABLE `ug_term_taxonomy` (
  `term_taxonomy_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dump dei dati per la tabella `ug_term_taxonomy`
--

INSERT INTO `ug_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'nav_menu', '', 0, 4),
(4, 4, 'wp_theme', '', 0, 2),
(6, 6, 'nav_menu', '', 0, 2),
(8, 8, 'att_categorie', '', 0, 1),
(9, 9, 'att_luoghi', '', 0, 1),
(10, 10, 'att_categorie', '', 0, 0),
(11, 11, 'att_categorie', '', 0, 0),
(12, 12, 'att_categorie', '', 0, 0),
(13, 13, 'att_categorie', '', 0, 0),
(14, 14, 'att_categorie', '', 0, 0),
(15, 15, 'att_categorie', '', 0, 0),
(16, 16, 'att_categorie', '', 0, 0),
(17, 17, 'att_categorie', '', 8, 0),
(18, 18, 'att_categorie', '', 8, 0),
(19, 19, 'att_categorie', '', 8, 1),
(20, 20, 'att_categorie', '', 8, 0),
(21, 21, 'att_categorie', '', 8, 1),
(22, 22, 'att_categorie', '', 8, 1),
(23, 23, 'att_categorie', '', 8, 0),
(24, 24, 'att_categorie', '', 8, 0),
(25, 25, 'att_categorie', '', 13, 0),
(26, 26, 'att_categorie', '', 13, 0),
(27, 27, 'att_categorie', '', 13, 0),
(28, 28, 'att_categorie', '', 13, 0),
(29, 29, 'att_categorie', '', 13, 1),
(30, 30, 'att_categorie', '', 8, 0),
(31, 31, 'att_categorie', '', 8, 0),
(32, 32, 'att_categorie', '', 13, 1),
(33, 33, 'att_categorie', '', 13, 0),
(34, 34, 'att_categorie', '', 13, 0),
(35, 35, 'att_categorie', '', 13, 0),
(36, 36, 'att_categorie', '', 8, 0),
(37, 37, 'att_categorie', '', 13, 0),
(38, 38, 'att_categorie', '', 8, 0),
(39, 39, 'att_categorie', '', 13, 0),
(40, 40, 'att_categorie', '', 13, 0),
(41, 41, 'att_categorie', '', 13, 0),
(42, 42, 'att_categorie', '', 8, 0),
(43, 43, 'att_categorie', '', 10, 0),
(44, 44, 'att_categorie', '', 10, 0),
(45, 45, 'att_categorie', '', 10, 0),
(46, 46, 'att_categorie', '', 10, 0),
(47, 47, 'att_categorie', '', 10, 0),
(48, 48, 'att_categorie', '', 15, 0),
(49, 49, 'att_categorie', '', 15, 0),
(50, 50, 'att_categorie', '', 15, 0),
(51, 51, 'att_categorie', '', 15, 0),
(52, 52, 'att_categorie', '', 15, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_usermeta`
--

CREATE TABLE `ug_usermeta` (
  `umeta_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dump dei dati per la tabella `ug_usermeta`
--

INSERT INTO `ug_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'emafer'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'ug_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'ug_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"57d4741a7b17bd0134620505f7ebb7f4eb2c932ad230054c79d3aa848ea7f1c2\";a:4:{s:10:\"expiration\";i:1700474431;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:101:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36\";s:5:\"login\";i:1700301631;}}'),
(17, 1, 'ug_dashboard_quick_press_last_post_id', '94'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(21, 1, 'ug_user-settings', 'libraryContent=browse'),
(22, 1, 'ug_user-settings-time', '1646637219'),
(23, 1, 'closedpostboxes_attivita', 'a:0:{}'),
(24, 1, 'metaboxhidden_attivita', 'a:0:{}'),
(25, 1, 'meta-box-order_attivita', 'a:3:{s:6:\"normal\";s:0:\"\";s:8:\"advanced\";s:13:\"attivita_meta\";s:4:\"side\";s:0:\"\";}'),
(26, 1, 'nav_menu_recently_edited', '3'),
(27, 1, 'ug_persisted_preferences', 'a:2:{s:14:\"core/edit-post\";a:4:{s:26:\"isComplementaryAreaVisible\";b:1;s:12:\"welcomeGuide\";b:0;s:14:\"fullscreenMode\";b:0;s:10:\"openPanels\";a:2:{i:0;s:11:\"post-status\";i:1;s:28:\"taxonomy-panel-att_categorie\";}}s:9:\"_modified\";s:24:\"2023-05-13T08:17:39.732Z\";}');

-- --------------------------------------------------------

--
-- Struttura della tabella `ug_users`
--

CREATE TABLE `ug_users` (
  `ID` bigint UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dump dei dati per la tabella `ug_users`
--

INSERT INTO `ug_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'emafer', '$P$Bpg05s2Kl.28TMFlzj0wxgmtiOE8do1', 'emafer', 'emanuele.ferrarini@gmail.com', 'http://urbigialla.com', '2022-03-06 18:13:38', '1679820328:$P$BcY6XblQWsuXqkj9ngTYvXxUgp928s.', 0, 'emafer');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `ug_commentmeta`
--
ALTER TABLE `ug_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indici per le tabelle `ug_comments`
--
ALTER TABLE `ug_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indici per le tabelle `ug_links`
--
ALTER TABLE `ug_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indici per le tabelle `ug_options`
--
ALTER TABLE `ug_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indici per le tabelle `ug_pmxi_files`
--
ALTER TABLE `ug_pmxi_files`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `ug_pmxi_hash`
--
ALTER TABLE `ug_pmxi_hash`
  ADD PRIMARY KEY (`hash`);

--
-- Indici per le tabelle `ug_pmxi_history`
--
ALTER TABLE `ug_pmxi_history`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `ug_pmxi_images`
--
ALTER TABLE `ug_pmxi_images`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `ug_pmxi_imports`
--
ALTER TABLE `ug_pmxi_imports`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `ug_pmxi_posts`
--
ALTER TABLE `ug_pmxi_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `ug_pmxi_templates`
--
ALTER TABLE `ug_pmxi_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `ug_postmeta`
--
ALTER TABLE `ug_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indici per le tabelle `ug_posts`
--
ALTER TABLE `ug_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indici per le tabelle `ug_termmeta`
--
ALTER TABLE `ug_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indici per le tabelle `ug_terms`
--
ALTER TABLE `ug_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indici per le tabelle `ug_term_relationships`
--
ALTER TABLE `ug_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indici per le tabelle `ug_term_taxonomy`
--
ALTER TABLE `ug_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indici per le tabelle `ug_usermeta`
--
ALTER TABLE `ug_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indici per le tabelle `ug_users`
--
ALTER TABLE `ug_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `ug_commentmeta`
--
ALTER TABLE `ug_commentmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_comments`
--
ALTER TABLE `ug_comments`
  MODIFY `comment_ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `ug_links`
--
ALTER TABLE `ug_links`
  MODIFY `link_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_options`
--
ALTER TABLE `ug_options`
  MODIFY `option_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=979;

--
-- AUTO_INCREMENT per la tabella `ug_pmxi_files`
--
ALTER TABLE `ug_pmxi_files`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_pmxi_history`
--
ALTER TABLE `ug_pmxi_history`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_pmxi_images`
--
ALTER TABLE `ug_pmxi_images`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_pmxi_imports`
--
ALTER TABLE `ug_pmxi_imports`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_pmxi_posts`
--
ALTER TABLE `ug_pmxi_posts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_pmxi_templates`
--
ALTER TABLE `ug_pmxi_templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_postmeta`
--
ALTER TABLE `ug_postmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=173;

--
-- AUTO_INCREMENT per la tabella `ug_posts`
--
ALTER TABLE `ug_posts`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT per la tabella `ug_termmeta`
--
ALTER TABLE `ug_termmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ug_terms`
--
ALTER TABLE `ug_terms`
  MODIFY `term_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT per la tabella `ug_term_taxonomy`
--
ALTER TABLE `ug_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT per la tabella `ug_usermeta`
--
ALTER TABLE `ug_usermeta`
  MODIFY `umeta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT per la tabella `ug_users`
--
ALTER TABLE `ug_users`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
